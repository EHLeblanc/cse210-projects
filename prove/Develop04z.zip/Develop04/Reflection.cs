using System;

public class Reflection
{
    private string _prompts;
    private string list _questions;
    private string _promptsAndQuestions;

    public Reflection()
    {

    }

    public DisplayPrompt()
    {

    }

    public DisplayQuestion()
    {
        
    }
}