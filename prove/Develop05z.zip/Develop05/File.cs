using System;

public class File
{
    private List<Goal> _entries;

    public File()
    {

    }

    public void SaveToFile()
    {

    }

    public void LoadFromFile()
    {
        
    }
}