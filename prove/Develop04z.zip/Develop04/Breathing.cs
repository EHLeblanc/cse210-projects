using System;

public class Breathing
{    
    private int _breatheIn;
    private int _breatheOut;

    public Breathing()
    {

    }

    void Breathe(BreathIn, breatheOut)
    {
        
    }
}
