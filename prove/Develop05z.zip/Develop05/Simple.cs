using System;

public class Simple
{
    public SimpleGoal(name, description, points)
    {

    }
    
    void CreateGoal()
    {

    }

    abstract void ListGoal()
    {

    }

    void RecordEvent()
    {

    }

    int Points()
    {
        
    }
}