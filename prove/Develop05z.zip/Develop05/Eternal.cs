using System;

public class Eternal
{
    public EternalGoal(name, description, points)
    {

    }

    void CreateGoal()
    {

    }

    void ListGoal()
    {

    }

    void RecordEvent()
    {

    }

    int Points()
    {

    }
    
}