using System;

public class Abstract
{
    protected string _name;
    protected string _description;
    protected int _points;

    public Goal(stringName, stringDescription, points)
    {

    }

    public abstract void CreateGoal()
    {

    }

    abstract void ListGoal()
    {

    }

    abstract void RecordEvent()
    {

    }

    abstract int Points()
    {
        
    }
}