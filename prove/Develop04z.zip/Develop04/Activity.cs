using System;

public class Activity
{
    protected string _activityName;
    protected string _activityDescription;
    protected string _duration;

    public Activity(stringName, intDuration)
    {
        
    }

    public string StartMessage()
    {

    }

    public string EndMessage()
    {

    }

    void Spinner(int secondsToRun)
    {

    } 

    void Countdown(int secondsToRun)
    {
        
    }
}