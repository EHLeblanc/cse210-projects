using System;

public class Activity
{
    private int _listCount;
    private List string _prompts;

    public Listing()
    {

    }

    public string DisplayPrompt()
    {
        
    } 
}