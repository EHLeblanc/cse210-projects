using System;

public class ChecklistGoal
{
    private int _checkCount;
    private int _bonusPoints;

    public ChecklistGoal(checkCount, bonusPoints)
    {
        base(name, description, points)
    }

    public void CreateGoal()
    {

    }

    public void ListGoal()
    {

    }

    public void RecordEvent()
    {

    }

    public int Points()
    {
        
    }
}